# Touchless Kiosk — SIU P2

**Sistemas Interactivos y Ubicuos · Grupo 9**  
Adam Kowalczyk Holtsova · Mohamed Rida Chahdaoui Moujib · David Benito Gil

---

## Descripción

Quiosco de comida rápida sin contacto táctil, controlado mediante gestos de mano capturados por webcam (MediaPipe Hands), comandos de voz (Web Speech API) y sincronización en tiempo real entre dispositivos (Socket.IO).

### Funcionalidades extra implementadas

1. Inicio automático por detección de presencia: al detectar al usuario frente al quiosco, la sesión pasa de `idle` a interacción activa sin pulsar ningún botón.
2. Control por voz multimodal: permite navegar categorías, saltar a una categoría concreta, añadir productos por nombre, confirmar y cancelar.
3. Reinicio total por gesto mantenido: gesto `V` mantenido durante 2 segundos para borrar pedido y reiniciar sesión, con feedback de progreso para evitar activaciones accidentales.

---

## Requisitos

- Node.js v18 o superior
- Chrome o Edge (necesitan WebRTC y Web Speech API; Firefox no soporta la API de voz)
- Webcam para la detección de gestos
- Red local compartida si se quiere usar la pantalla display en otro dispositivo

---

## Instalación y arranque

```bash
cd touchless-kiosk
npm install
npm start
```

El servidor arranca en http://localhost:3000

---

## Pantallas del sistema

| Pantalla | URL | Uso |
|---|---|---|
| Kiosk | `http://localhost:3000/kiosk` | Pantalla principal de pedido con cámara y gestos |
| Display | `http://localhost:3000/display` | Pantalla secundaria para el mostrador |

Para acceder al display desde otro dispositivo en la misma red, sustituye `localhost` por la IP del servidor (por ejemplo: `http://192.168.1.X:3000/display`).

---

## Gestos

| Gesto | Acción |
|---|---|
| Presencia (muñeca detectada) | Inicia la sesión automáticamente |
| Señalar con el índice y mantener ~1.25 s | Selecciona el producto sobre el que apuntas |
| Inclinar la muñeca hacia un lado | Cambia de categoría (izquierda / derecha) |
| Pulgar arriba (~0.85 s estable) | Confirma selección o pago |
| Palma abierta (~0.85 s estable) | Cancela el último paso |
| V (índice + corazón) mantenida 2 s | Elimina todo el pedido — difícil de activar accidentalmente |

La navegación por inclinación de muñeca funciona midiendo el ángulo del eje muñeca–palma respecto a la vertical. Basta con inclinar la mano unos 28 grados durante medio segundo; no hace falta hacer ningún movimiento brusco.

El gesto de reset total (V mantenida) requiere mantener los dos dedos extendidos y separados durante dos segundos seguidos. El porcentaje de progreso aparece en el indicador de la cámara.

---

## Comandos de voz

Activa el micrófono con el botón de la pantalla kiosk y di:

- Nombre del producto: "burger", "cola", "fries"...
- Categoría: "burgers", "drinks", "sides", "desserts"
- Navegación: "siguiente" / "next"
- Confirmar: "confirmar" / "pagar" / "confirm"
- Cancelar: "cancelar" / "atrás" / "cancel"

La modalidad de voz está diseñada como interacción complementaria a los gestos: puede sustituir temporalmente la interacción gestual para mejorar accesibilidad y reducir fricción en escenarios de uso real.

---


### 1) Inicio automático de sesión por presencia

El sistema incorpora una activación implícita por presencia, de modo que la sesión comienza automáticamente cuando se detecta al usuario frente al quiosco. Esto reduce pasos innecesarios y refuerza la idea de interacción invisible y sin contacto.

### 2) Control por voz del sistema

Como funcionalidad adicional, se integró una modalidad de interacción por voz que permite complementar o sustituir temporalmente los gestos. El usuario puede navegar por el menú, seleccionar productos y confirmar acciones mediante comandos hablados, mejorando la accesibilidad y la flexibilidad del sistema.

### 3) Reinicio completo mediante gesto mantenido

Se añadió una acción específica de reinicio total del pedido mediante un gesto mantenido, diseñada para evitar activaciones accidentales. Esta funcionalidad permite al usuario cancelar completamente la sesión actual de forma rápida, clara y coherente con el paradigma de interacción gestual.

---

## Arquitectura

```
[Webcam / Micrófono]
        |
[MediaPipe Hands / Web Speech API]
        |
[Socket.IO Client — Kiosk]
        |  WebSocket
[Node.js + Express + Socket.IO — Server :3000]
        |  WebSocket broadcast
[Socket.IO Client — Display]
```

---

## Estructura del proyecto

```
touchless-kiosk/
├── server/
│   └── index.js          # Servidor Node.js + Express + Socket.IO
├── public/
│   ├── kiosk/
│   │   └── index.html    # Pantalla de interacción (gestos + voz)
│   ├── display/
│   │   └── index.html    # Pantalla secundaria (TV / mostrador)
│   ├── css/
│   │   └── shared.css    # Estilos compartidos
│   └── js/
│       └── kiosk.js      # Lógica de gestos + voz + Socket.IO cliente
├── package.json
└── README.md
```
